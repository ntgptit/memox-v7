/* MemoX — Search. States: empty-recent · results · filtered · no-results · loading */
(function () {
const NS = window.MemoXDesignSystem_2ffa54;
const { MxScaffold, MxAppBar, MxIconButton, MxSearchDock, MxChip, MxCard, MxBadge } = NS;

const FILTERS = ['All', 'New', 'Due', 'Mastered'];
const STATUS = {
  new: { label: 'New', tone: undefined },
  due: { label: 'Due', tone: 'error' },
  mastered: { label: 'Mastered', tone: 'success' },
};
const RESULTS = [
  { term: '공부하다', meaning: 'to study', deck: 'TOPIK I — Vocabulary', status: 'due' },
  { term: '좋아하다', meaning: 'to like', deck: 'Common Verbs', status: 'mastered' },
  { term: '하다', meaning: 'to do (auxiliary)', deck: 'TOPIK I — Vocabulary', status: 'new', hidden: true },
];
const RECENT = ['안녕하세요', '학교', '감사합니다'];

function ResultRow({ term, meaning, deck, status, hidden, node }) {
  const s = STATUS[status];
  return (
    <div data-mx-node={node} style={{ display: 'flex', alignItems: 'center', gap: 'var(--memox-space-4)', opacity: hidden ? .5 : 1 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--memox-space-2)' }}>
          <span style={{ fontWeight: 'var(--memox-font-weight-extrabold)', fontSize: 'var(--memox-font-size-md)' }}>{term}</span>
          {hidden ? <span className="material-symbols-rounded" style={{ fontSize: 'var(--memox-font-size-base)', color: 'var(--memox-text-tertiary)' }}>visibility_off</span> : null}
        </div>
        <div style={{ fontSize: 'var(--memox-font-size-sm)', color: 'var(--memox-text-secondary)', marginTop: 'var(--memox-space-1)' }}>{meaning}</div>
        <div style={{ fontSize: 'var(--memox-font-size-sm)', color: 'var(--memox-text-tertiary)', marginTop: 'var(--memox-space-1)' }}>{deck}</div>
      </div>
      <MxBadge tone={s.tone} soft>{s.label}</MxBadge>
    </div>
  );
}

function Chips({ active }) {
  return (
    <div data-mx-node="search/filters" style={{ display: 'flex', gap: 'var(--memox-space-2)', overflowX: 'auto', paddingBottom: 'var(--memox-space-1)' }}>
      {FILTERS.map((f, i) => <MxChip key={f} label={f} selected={i === active} node={'search/filter-' + i} />)}
    </div>
  );
}

function Search({ state = 'empty-recent' }) {
  const val = state === 'empty-recent' ? '' : (state === 'no-results' ? 'xyz' : '하');
  const bar = (
    <MxAppBar node="search/appbar"
      leading={<MxIconButton icon="arrow_back" node="search/back" />}
      title={<MxSearchDock value={val || undefined} placeholder="Search by word or meaning" node="search/dock"
        trailing={val ? <MxIconButton icon="close" size="sm" node="search/clear" /> : null} />} />
  );

  if (state === 'empty-recent') {
    return (
      <MxScaffold node="search/screen" appBar={bar}>
        <div style={{ fontSize: 'var(--memox-font-size-sm)', fontWeight: 'var(--memox-font-weight-bold)', color: 'var(--memox-text-tertiary)', letterSpacing: 'var(--memox-letter-spacing-wide)', margin: 'var(--memox-space-1) 0 0 var(--memox-space-1)' }}>RECENT</div>
        <MxCard padding="sm">
          {RECENT.map((r, i) => (
            <window.ListRow key={r} icon="history" title={r} last={i === RECENT.length - 1} node={'search/recent-' + i}
              trailing={<MxIconButton icon="north_west" size="sm" node={'search/recent-fill-' + i} />} />
          ))}
        </MxCard>
      </MxScaffold>
    );
  }

  if (state === 'loading') {
    const S = window.Skeleton;
    return (
      <MxScaffold node="search/screen" appBar={bar}>
        <Chips active={0} />
        {[0, 1, 2].map((i) => (
          <MxCard key={i} padding="sm"><S w="40%" h={16} /><S w="62%" h={10} style={{ marginTop: 'var(--memox-space-2)' }} /><S w="50%" h={10} style={{ marginTop: 'var(--memox-space-2)' }} /></MxCard>
        ))}
      </MxScaffold>
    );
  }

  if (state === 'no-results') {
    return (
      <MxScaffold node="search/screen" appBar={bar}>
        <Chips active={0} />
        <window.EmptyState node="search/no-results" icon="search_off" tone="warning" title="No matches"
          text={'Nothing matched “xyz”. Try another term or check the spelling.'} />
      </MxScaffold>
    );
  }

  const filtered = state === 'filtered';
  const rows = filtered ? RESULTS.filter((r) => r.status === 'due') : RESULTS;
  return (
    <MxScaffold node="search/screen" appBar={bar}>
      <Chips active={filtered ? 2 : 0} />
      {rows.map((r, i) => (
        <MxCard key={i} padding="sm" interactive node={'search/result-' + i}><ResultRow {...r} /></MxCard>
      ))}
    </MxScaffold>
  );
}

window.Search = Search;
})();
